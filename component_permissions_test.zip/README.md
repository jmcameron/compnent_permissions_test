compnent_permissions_test
=========================

Joomla component for testing specifying defaults for component-defined
permissions

Should work on Joomla 2.5.x and 3.x with patches to platform.

To use this, install the component in the regular way then go to the
'component-permissions-test' component under the 'Components' menu in the back
end.  There are instructions there on how to test it.

Jonathan Cameron
April 11, 2013
